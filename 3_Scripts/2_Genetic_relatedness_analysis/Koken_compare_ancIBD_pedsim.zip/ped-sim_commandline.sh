
   
~/bin/ped-sim-1.4/ped-sim -d ancibd_background_males.def -m ../240125_simtest/refined_mf.simmap \
-o ancibd_background_males --intf ~/bin/ped-sim-1.4/interfere/nu_p_campbell.tsv --fam
 