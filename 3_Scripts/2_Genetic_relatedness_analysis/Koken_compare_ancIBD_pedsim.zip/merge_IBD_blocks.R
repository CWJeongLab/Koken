library(tidyverse); library(data.table)

merge_ibd_segs_v2 <- function(res) {
  test <- res %>%
    arrange(iid1,iid2, chrom, start ) 
  
  test_1 <- test # Action happens in place of test_1.
  
  ibdmerge=FALSE
  blockindex = 1 # index of the "start" block
  indexvector <- numeric(nrow(test_1))
  count = 1
  for(i in 2:nrow(test_1)) {
    if((test[i,]$iid1 != test[i-1,]$iid1 & test[i,]$iid2 != test[i-1,]$iid2) | test[i,]$chrom != test[i-1,]$chrom | test[i,]$start - 1 != test[i-1,]$end ) {
      # check if iid is different or chromosome is different (always change of block)
      
      indexvector[count] = blockindex 
      count = count +1
      blockindex = i
      next # Skip
    }
    
    if(test_1[i,]$start - 1 == test_1[i-1,]$end) { # merging needed
      test_1[blockindex,]$end =test_1[i,]$end
      test_1[blockindex,]$genend =test_1[i,]$genend
      test_1[blockindex,]$genlen =test_1[i,]$genlen + test_1[blockindex,]$genlen
    }
  }
  indexvector[count] = blockindex
  return(test_1[unique(indexvector[indexvector != 0]),])
}
res <- read.table("ancibd_background_males.seg")
names <- c("iid1", "iid2", "chrom", "start", "end", "IBDtype", "genstart", "genend", "genlen")
names(res) <- names

res <- merge_ibd_segs_v2(res)
snps = data.table::fread("1240K.240829.snp")
names(snps) = c("snpID", "chrom", "M", "pos", "Ref","Alt")
setDT(res)
setDT(snps)
names(res)
ranges_snp <- snps[res,
    on = .(chrom ==chrom, pos >= start, pos <= end),
    .N,
    by= .EACHI
    ] ## We use non-equi join.
res_final <- res[,snp_count := ranges_snp$N]
res_final
summary <- res_final %>%
  mutate(density = snp_count/genlen) %>%
  filter(genlen > 12 & density >= 220) %>% 
  group_by(iid1,iid2) %>%
  summarise(length = sum(genlen), count = n()) %>%
  ungroup %>%   
  mutate(color = str_remove(paste0(iid1,iid2), "[0-9]+_.+$"))

summary %>% write.csv(row.names =FALSE, file = "ancibd_background_males.csv")

  