library(tidyverse)
koken = read.table("Koken_ancIBD_ind.tsv",header = T)
background = read.csv("ancibd_background_males.csv")

pdf("Figure_S11.pdf", width = 7, height = 6)
a<- background %>% 
  filter(color %in% c("Double Cousin", "Avuncular", "Grandparent Grandchild", "Half Sibling")) %>% 
  ggplot(aes(x = length, y = count )) +
  geom_point(aes(color = color), size = 2) +
  geom_point(data = koken, aes(y = n_IBD.12, x =sum_IBD.12), color = "black", shape = 15, size = 5  ) +
  xlab("Sum of IBD >12cM [cM]") +
  ylab("Number of IBD >12cM [Count]") +
  theme_bw() +
  guides(color = guide_legend(title = "2nd degree relationships"))
print(a)
dev.off()
ggsave("Figure_S11.png")
